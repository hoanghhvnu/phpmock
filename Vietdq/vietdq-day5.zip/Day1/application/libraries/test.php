<?php
class test
{
    function debug($data = array()) 
    {
        echo "<pre>";
        print_r($data);
        echo "</pre>";
    }
}