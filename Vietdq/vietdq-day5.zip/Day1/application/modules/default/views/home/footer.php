</div>
    <div id="footer">
    	Training PHP Project 
    </div>
</body>
</html>
