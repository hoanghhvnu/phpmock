<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>WEB BÁN HÀNG</title>
<link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>/public/default/css/style.css" />
</head>
<body>
	<div id="banner">&nbsp;</div>
    <div id="menu">
    	<ul>
        	<li><a href="#">Trang chủ</a></li>
            <li><a href="#">Giới thiệu</a></li>
            <li><a href="#">Tin tức</a></li>
            <li><a href="#">Sản phẩm</a></li>
            <li><a href="#">Dịch vụ</a></li>
            <li><a href="#">Khuyến mãi</a></li>
            <li><a href="#">Liên hệ</a></li>
            <li><a href="#" style="border:none;">Sitemap</a></li>
        </ul>
    </div>
    <div id="main">