<div id="left">
        	<div class="category">
            	<h1>Danh m?c s?n ph?m</h1>
                <ul>
    	        	<li><a href="#">Sony</a></li>
                    <li><a href="#">Dell</a></li>
                    <li><a href="#">Iphone</a></li>
                    <li><a href="#">Asus</a></li>
                    <li><a href="#">Lenovo</a></li>
                    <li><a href="#">Sky</a></li>
                    <li><a href="#">Nokia</a></li>
                    <li><a href="#">Sam sung</a></li>
                    <li><a href="#">HTC</a></li>
	            </ul>
            </div>
            
            <div class="category" id="online">
            	<h1>Qu?ng cáo</h1>
                <img src="<?php echo base_url() ?>/public/default/images/doitac.jpg" width="198" />
                <hr />
                <img src="<?php echo base_url() ?>/public/default/images/suntech.jpg" width="198" />
            </div>
            
        </div>
        <div id="center">