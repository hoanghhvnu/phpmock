<?php
    $this->load->view("top");
    $this->load->view("left");
    $this->load->view($template);
    $this->load->view("right");
    $this->load->view("footer");
    	
		
        
    