<h1>Chi tiet san pham</h1>
<?php
    echo "<pre>";
    print_r($infoProduct);