<?php
class product extends CI_Controller
{
    public function  __construct()
    {
        parent::__construct();
        $this->load->model("product_model");
        $this->load->model("category_model");
        $this->load->model("cateproduct_model");
        $this->load->model("bran_model");
        $this->load->model("country_model");
        $this->load->model("images_model");
        $this->load->library("form_validation");
        
     
    }
    public function index()
    {
       echo __METHOD__;
    }
    public function update()
    {
        $id = $this->uri->segment(4);
        $data['productInfo'] = $this->product_model->detail($id);
        $rows = $this->category_model->detail($id);
        //lay ra danh sach category

        $cateIdArr =  $this->cateproduct_model->getCate($id);
        $cateArr = array();
        if(isset($cateIdArr) && $cateIdArr != null) {
            foreach($cateIdArr as $valCate) {
                $cateArr[] = $valCate['cate_id'];
            }
        }
        $data['listCateid'] = $cateArr;      
        //get bran   
        $data['bran'] =$this->bran_model->getAll();
        //get country
        $data['country'] =$this->country_model->getAll();    
        // lay ra category
        $data['listCategory'] = $this->getDataInsertCategory(0);
        // lay ra anh
        $data['listImages'] = $this->images_model->listImages($id);
        $listImages= $this->images_model->listImages($id);
        // lay so luong anh
        $numberImages = $this->images_model->countImages($id);
        // Thuc hien viec update
         if($this->input->post("ok")){
           $this->form_validation->set_rules("pro_name","Ten product ","trim|required");        
            $this->form_validation->set_rules("pro_price","Gia goc ","trim|required|numeric");
            $this->form_validation->set_rules("pro_price_sale","Gia ban ","trim|required|numeric");
            $this->form_validation->set_rules("pro_desc","Mo ta san pham ","trim|required");
            $this->form_validation->set_rules("pro_info","Thong tin ","trim|required");
            $this->form_validation->set_rules("pro_status","Trang thai ","trim|required|numeric");
            $this->form_validation->set_rules("bran_id","Ten nhan","trim|required|numeric");
            $this->form_validation->set_rules("country_id","Gia ban ","trim|required|numeric");
            $this->form_validation->set_rules("pro_quantity","So luong ","trim|required|numeric");
            $this->form_validation->set_message("required","%s khong duoc bo trong");
            $this->form_validation->set_message("numeric","%s phai la so");
            $this->form_validation->set_error_delimiters("<span class='error'>","</span>");
            if($this->form_validation->run()){

                $updateName=$this->input->post("pro_name");
                $listall=$this->product_model->getAll();
                foreach ($listall as $row) {
                if (in_array(trim($updateName),$row)&& ($row['pro_id']!=$id)) $data['errorName']="Da ton tai";

                }   
                if ($_FILES['file']['error']==0&&$numberImages>=10) $data['errorImages'] = "Da du 10 anh";
                else
                if (!isset($data['errorName'])) {
                     $cate=array();
                     $cate=$this->input->post("category");
                     $this->cateproduct_model->deleteCate($id);
                     foreach($cate as $key=>$val) {
                       echo $val;
                       $datacate= array( 
                           "cate_id"=>$val,
                           "pro_id"=>$id,
                           "catepro_order"=>'1'   
                       );
                    $this->cateproduct_model->insertCate($datacate);     
                }
                $dataProduct = array(
                    "pro_name"=>$this->input->post("pro_name"),
                    "pro_price"=>$this->input->post("pro_price"),
                    "pro_price_sale"=>$this->input->post("pro_price_sale"),
                    "pro_desc"=>$this->input->post("pro_desc"),
                    "pro_info"=>$this->input->post("pro_info"),
                    "pro_status"=>$this->input->post("pro_status"),
                    "bran_id"=>$this->input->post("bran_id"),
                    "country_id"=>$this->input->post("country_id"),
                    "pro_quantity"=>$this->input->post("pro_quantity")     
                    );     
                $this->product_model->update($dataProduct,$id);                
                $filename=$_FILES['pro_images']['name'];
                if ($_FILES['pro_images']['error']==0) {                    
                
                $proImages = array (
                               "pro_images"=>$filename,
      
                );
                $this->upImage('pro_images');
                $this->product_model->update($proImages,$id);
                }
                foreach($listImages as $val) {
                
                $img="image".$val['img_id'];
                if (($_FILES[$img]['error'])==0)
                    {  
                        echo $val['img_id'];
                
                        $image1=$_FILES[$img];

                        $filename=$_FILES[$img]['name'];
                   
                        $imageInfo = array (
                               "img_name"=>$filename,
                               "pro_id"=>$id,
                               
                
                );
                        $this->upImage($img);
                        $this->images_model->update($imageInfo,$val['img_id']);
                    }
                   }
                if ($numberImages<10) {

                $filename=$_FILES['file']['name'];
                if ($_FILES['file']['error']==0) {
                echo $filename;
                $imageInfo = array (
                               "img_name"=>$filename,
                               "pro_id"=>$id,
                               
                
                );
                $this->upImage('file');

                $this->images_model->insert($imageInfo);
                }
                }
           
             
                redirect(base_url("/Day1/administrator/product/update/$id"));
                }
                 
                }
         }
        
       
        $this->load->view("administrator/product/update",$data);
    }
    public function deleteImages($id) {
        $id = $this->uri->segment(4);
        $infoImg = $this->images_model->getImg($id);
  
        $namedel=$infoImg['img_name'];
        $file = "uploads/product/".$namedel;
        $this->images_model->deleteImg($id); 
        

       
       if (!unlink($file))
            {
               // echo ("Error deleting $file");
            }
        else
            {
                //echo ("Deleted $file");
            }


        
    }
    private function getDataInsertCategory($parent = 0,$gach = '-  ',$data = NULL)
    {
        if(!$data) $data = array();
    
        $sql = $this->category_model->detailparent($parent);
        //print_r ($sql);
        foreach($sql as $key=>$value){
            $data[] = array(
                        'cate_id'    =>$value['cate_id'],
                        'cate_name'  =>$gach.$value['cate_name'],
                        'cate_parent'=>$value['cate_parent']
                        );
            $data = $this->getDataInsertCategory($value['cate_id'],$gach.'---   ',$data);
        }

        
        return $data;
    }
    public function upImage($file) {
                $config['overwrite'] = TRUE;
                $config['allowed_types'] = 'jpg|jpeg|gif|png';
                $config['max_size'] = 2000;
                $config['upload_path'] = 'uploads/product/';
                $this->load->library('upload', $config);
                $this->upload->initialize($config);
                $this->upload->do_upload($file);
    }
    
}